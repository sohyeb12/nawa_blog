<?php if(session()->has('error')): ?>
<div class="alert alert-success">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>


<div class="container">
    <div class="col-md-8">
        <div class="mb-3">
            <label for="name">Name User: </label>
            <div>
                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" value="<?php echo e(old('name',$user->name)); ?>" placeholder="Enter Name User">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="mb-3">
            <label for="email">Email User: </label>
            <div>
                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="<?php echo e(old('email',$user->email)); ?>" placeholder="Enter Email User">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>


        <div class="mb-3">
            <label for="status">Status: </label>
            <div>
                <?php $__currentLoopData = $status_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input type="radio" class="form-check-input" name="status" id="status_<?php echo e($key); ?>" value="<?php echo e($key); ?>" <?php if($key==old('status',$user->status) ): echo 'checked'; endif; ?>>
                    <label class="form-check-label" for="status_<?php echo e($key); ?>"><?php echo e($value); ?></label>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>


        <div class="mb-3">
            <label for="type">User Type: </label>
            <div>
                <?php $__currentLoopData = $user_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input type="radio" class="form-check-input" name="type" id="type_<?php echo e($key); ?>" value="<?php echo e($key); ?>" <?php if($key==old('type',$user->type) ): echo 'checked'; endif; ?>>
                    <label class="form-check-label" for="type_<?php echo e($key); ?>"><?php echo e($value); ?></label>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <button type="submit" class="btn btn-primary"><?php echo e($btn_submit ?? 'Save'); ?></button>
    </div>
</div><?php /**PATH E:\blog_nawa\resources\views/admin/users/update.blade.php ENDPATH**/ ?>