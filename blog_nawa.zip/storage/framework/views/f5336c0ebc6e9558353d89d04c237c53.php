

<?php $__env->startSection('content'); ?>
<header class="mb-4 d-flex">
    <h2 class="mb-4 fs-3"> <?php echo e($title); ?> </h2>
    <div class="ml-auto">
        <a href="<?= route('users.create') ?>" class="btn btn-sm btn-primary">+ Create Product</a>

    </div>
</header>


<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>


<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Status</th>
            <th>Type</th>
            <th>Created_at</th>
            <th></th>
            <th></th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->id); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->status); ?></td>
            <td><?php echo e($user->type); ?></td>
            <td><?php echo e($user->created_at); ?></td>


            <td><a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn -sm btn-outline-dark"><i class="fas fa-edit"></i> Edit User Info</a> </td>
            <td>
                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("delete"); ?>
                    <button type="submit" class="btn btn -sm btn-danger"><i class="fas fa-trash"></i> Delete</button>
                </form>
            </td>
            <td><a href="<?php echo e(route('users.edit-password' , $user->id)); ?>" class="btn btn -sm btn-outline-dark"><i class="fas fa-edit"></i> Edit Password</a> </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div>
    <?php echo e($users->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\blog_nawa\resources\views/admin/users/index.blade.php ENDPATH**/ ?>