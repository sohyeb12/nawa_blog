

<?php $__env->startSection('content'); ?>
<header class="mb-4 d-flex">
    <h2 class="mb-4 fs-3"> <?php echo e($title); ?> </h2>
    <div class="ml-auto">
        <a href="<?= route('blog_informations.create') ?>" class="btn btn-sm btn-primary">+ Create New</a>

    </div>
</header>
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>


<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Created_at</th>
            <th>LOGO</th>
            <th></th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php if(isset($blog_information)): ?>
        <tr>
            <td><?php echo e($blog_information->id); ?></td>
            <td><?php echo e($blog_information->name); ?></td>
            <td><?php echo e($blog_information->created_at); ?></td>
            <td>
                <a href="<?php echo e($blog_information->image_url); ?>">
                    <img src="<?php echo e($blog_information->image_url); ?>" alt="" width="60">
                </a>
            </td>
            
            <td><a href="<?php echo e(route('blog_informations.edit', $blog_information->id)); ?>" class="btn btn -sm btn-outline-dark"><i class="fas fa-edit"></i> Edit</a> </td>
            
        </tr>
        
        <?php endif; ?>
    </tbody>
</table>

<div>
    <!-- paginte -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\blog_nawa\resources\views/admin/blog_informations/index.blade.php ENDPATH**/ ?>