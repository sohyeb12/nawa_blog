	

	<?php $__env->startSection('blog'); ?>
	<!--Page Title-->
	<section class="page-title" style="background-image:url(images/background/7.jpg);">
		<div class="auto-container">
			<h1><?php echo e($blog_information->name); ?></h1>
			<div class="text">What We Actually Do?</div>
			<ul class="bread-crumb clearfix">
				<li><a href="index.html"><span class="fas fa-home"></span> Home </a></li>
				<li>Latest News</li>
			</ul>
		</div>
	</section>
	<!--End Page Title-->

	<!-- Blog Page Section -->
	<section class="blog-page-section">
		<div class="auto-container">
			<div class="row clearfix">

				<!-- News Block Two -->
				<!-- edit now -->
				<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="news-block-two col-lg-6 col-md-12 col-sm-12">
					<div class="inner-box">
						<div class="image">

							<a href="<?php echo e(route('show.article' , $article->id)); ?>"><img src="<?php echo e($article->image_url); ?>" alt="" width="500" height="300"/></a>
						</div>
						<div class="lower-content">
							<div class="content">
								<ul class="post-info">
									<li><span class="icon flaticon-chat-comment-oval-speech-bubble-with-text-lines"></span> <?php echo e($article->comments_count); ?></li>
									<!-- <li><span class="icon flaticon-heart"></span> 126</li> -->
								</ul>
								<ul class="post-meta">
									<li><?php echo e($article->created_at); ?></li>
									<li>Post By: <?php echo e($article->user->name); ?></li>
								</ul>
								<h3><a href="<?php echo e(route('show.article' , $article->id)); ?>"><?php echo e($article->title); ?></a></h3>
								<div class="text"><?php echo e(substr($article->article_text,0,122)); ?> ...</div>
								<a href="<?php echo e(route('show.article' , $article->id)); ?>" class="theme-btn btn-style-five"><span class="txt">read more</span></a>
							</div>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


			</div>

			<!-- Styled Pagination -->
			<div class="styled-pagination text-center">
				<ul class="inner-container clearfix">
					<!-- <li class="prev"><a href="#" class="active"><i class="flaticon-left-arrow"></i> Prev</a></li>
					<li><a href="#">1</a></li>
					<li><a href="#">2</a></li>
					<li class="active"><a href="#">3</a></li>
					<li><a href="#">4</a></li>
					<li><a href="#">5</a></li>
					<li class="next"><a href="#" class="active">Next <i class="flaticon-right-arrow-1"></i></a></li> -->

					<?php echo e($articles->links()); ?>

				</ul>
			</div>

		</div>
	</section>
	<!-- End Portfolio Page Section -->

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\blog_nawa\resources\views/blog/home.blade.php ENDPATH**/ ?>