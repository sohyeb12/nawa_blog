

<?php $__env->startSection('content'); ?>
        <h2 class="mb-4 fs-3"><?php echo e('Information Blog:'); ?></h2>
        <form action="<?= route('blog_informations.store') ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('admin.blog_informations._form',['btn_submit' => 'Create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\blog_nawa\resources\views/admin/blog_informations/create.blade.php ENDPATH**/ ?>