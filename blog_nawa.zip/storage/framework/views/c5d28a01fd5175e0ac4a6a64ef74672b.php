

<?php $__env->startSection('content'); ?>

<h2 class="mb-4 fs-3">Edit Password User: </h2>
<!-- enctype="multipart/form-data" -->
<form action="<?php echo e(route('users.update-password', $user->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>

    <div class="mb-3">
        <label for="password">New Password: </label>
        <div>
            <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password" value="" placeholder="Enter Password User">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="invalid-feedback"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="mb-3">
        <label for="password_confirmation">Confirm Password: </label>
        <div>
            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Confirm Password:">
        </div>
    </div>

    <button type="submit" class="btn btn-primary">Update</button>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\blog_nawa\resources\views/admin/users/edit-password.blade.php ENDPATH**/ ?>