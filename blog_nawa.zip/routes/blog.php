<?php

use App\Http\Controllers\ArticlesController;
use App\Http\Controllers\CommentsController;
use App\Http\Controllers\ContactUsController;
use Illuminate\Support\Facades\Route;

Route::get('/articles/{id}',[ArticlesController::class , 'show'])->name('show.article');
Route::post('/contact_us',[ContactUsController::class , 'store'])->name('store.comments');